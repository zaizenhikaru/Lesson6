# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '47be8d16376fd2f844820df1b58744f3e86731743a51f8e7cf5461996a0c1504c4ce349548cc121f9147637f52925fb2719334a23ddecb03312a8ecd32824927'